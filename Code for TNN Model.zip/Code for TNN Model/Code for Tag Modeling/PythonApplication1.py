import gensim
from gensim import corpora
from gensim.utils import simple_preprocess
from gensim.models import LdaModel
from nltk.corpus import stopwords
import nltk

# Download NLTK stopwords
nltk.download('stopwords')

# Sample questions: Replace this with your actual data
questions = [
    "How to implement a binary search in Python?",
    "What is the difference between 'let' and 'var' in JavaScript?",
    # ... more questions
]

# Set up stopwords
stop_words = set(stopwords.words('english'))

# Preprocess the text data
def preprocess(text):
    return [word for word in simple_preprocess(text) if word not in stop_words]

# Process all questions to word tokens
processed_questions = [preprocess(question) for question in questions]

# Create a dictionary and corpus needed for LDA
dictionary = corpora.Dictionary(processed_questions)
corpus = [dictionary.doc2bow(text) for text in processed_questions]

# Train the LDA model on the corpus
lda_model = LdaModel(corpus, num_topics=10, id2word=dictionary, passes=10)

# Show the topics
for idx, topic in lda_model.print_topics(-1):
    print('Topic: {} \nWords: {}'.format(idx, topic))

# Predict the tag for a new question
new_question = "How do I reverse a list in Python?"
new_question_preprocessed = preprocess(new_question)
new_question_bow = dictionary.doc2bow(new_question_preprocessed)
new_question_lda = lda_model[new_question_bow]

print(new_question_lda)

# Determine the most likely topic (and thus tag category) for the new question
most_likely_topic = max(new_question_lda, key=lambda item: item[1])
print(f"The most likely topic (tag) for the new question is: Topic {most_likely_topic[0]}")

# Optionally, you can show the words associated with the predicted tag
print(lda_model.show_topic(most_likely_topic[0]))
